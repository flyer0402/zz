# -*- coding: UTF-8 -*-
'''
Created on 2021年1月22日

@author: quan.dq
'''
from email.utils import getaddresses
import os
from pickle import FALSE, TRUE
import gdb
import re
import tmallochelper as tm
import utils
import updatemapsbychunk

class Memoryinfo(gdb.Command):
    allMstate = None
    allChunmaps =None
    def __init__(self):
        super(Memoryinfo, self).__init__ ("memoryinfo", gdb.COMMAND_SUPPORT, gdb.COMPLETE_NONE, True)
        #print("__init__")
        #self.allMstate = np.empty([6,2], dtype = int64)
        #self.allMstate = np.array([], dtype = int64)
        #self.maps = np.array([], dtype = int64)
        
    def __usage(self):
        print("Usage: \n")
        print("memoryinfo maps\t Get all pointer from maps,1G mem or 600w pointer need 3min")
        print("memoryinfo main_arena\t update maps by free chunk, 1G mem or 600w pointer need 20min")
        return None
    
    def getMapsByInfoFiles(self):
        result = []
        sections = gdb.execute("info files", False, True)
        for line in sections.split('\n'):
            line = line.strip()
            fields = line.split(' ')
            if len(fields) >= 3 and fields[1] == "-" and fields[0].startswith("0x") and fields[2].startswith("0x") and fields[4].startswith("load"):
                start = int(fields[0], 16)
                end = int(fields[2], 16)
                if end - start <= 4096:
                    continue
                #print "%d, %d" , start, end
                result.append([start, end])
        return result

    def getMapsByMapsFile(self,filename):
        result = []
        file = open(filename) 
        while 1:
            line = file.readline()
            if not line:
                break
            if self.update:
                result.append(line)
                continue
            fields = line.split(' ')
            startend= fields[0].split('-')
            start = int(startend[0], 16)
            end = int(startend[1], 16)
            rw = str(fields[1])
            mapsfile=fields[len(fields)-1].rstrip()
            #if end - start <= 4096:
            #    continue
            #print('%#x %#x %d %d'%(start,end,(end-start),(end - start > tm.mmap_threshold)))
            if rw.startswith("rw"):
                ismalloc=False
                if mapsfile=="" and (end - start > tm.mmap_threshold):
                    ismalloc=True
                if mapsfile == "[heap]":
                    ismalloc=True
                if ismalloc==True:
                    #print('%#x %#x %d'%(start,end,(end-start)))
                    result.append([start, end])
                
        return result
    
    def getMaps(self,fileName=None):
        file=os.path.abspath('.')+"/maps"
        if fileName != None:
            file = fileName 
        print(file)
        if os.path.isfile(file):
            return  self.getMapsByMapsFile(file)
        else:
            if self.update:
                maps=self.getMapsByInfoFiles()
                return self.transition(maps)
            else:
                return self.getMapsByInfoFiles()
             
    def getAllChunk(self,maps):
        size = len(maps)
        if  size == 0:
            print("getAllChunk maps is null")
        result = []
        for map in maps:
            # print('%#x %#x'%(map[0],map[1]))
            c = tm.Chunk(map[0])
            c.mapbeginaddr = map[0]
            c.mapendaddr = map[1]
            #if(c.mchunk_size != 0 and c.mchunk_size >= tm.MIN_CHUNK_SIZE and  (c.addr + c.size <= map[1])):
            #    result.append(c)
            #while c.mchunk_size != 0 and c.mchunk_size >= tm.MIN_CHUNK_SIZE:
            while c.mchunk_size != 0 and c.mchunk_size >=16:
                #print('%#x %d <= %d'%(c.addr,c.size,(c.mapendaddr - c.addr)))
                if c.addr + c.size > map[1]:
                    break
                elif  c.addr + c.size == map[1]:
                    result.append(c)
                    break
                else:
                    result.append(c)
                    tmp = c
                addr = c.nextchunk()
                c = tm.Chunk(addr)
                c.mapbeginaddr = map[0]
                c.mapendaddr = map[1]
                tmp.inuse = tm.Chunk.isuse(c)
                #print('%#x %#x'%(c.addr,c.size()))
                
        return result        
    def createatrace(self):
        fo = open("maps.atrace", "w")
        utils.writeatracehead(fo)
        firstaddr=0
        for chunk in self.allChunmaps:
            #print('%#x %#x'%(chunk.addr,chunk.size))
            addr=int(chunk.addr)
            size=chunk.size
            end=int(addr+size)
            inuse=chunk.inuse
            head=chunk.mapbeginaddr
            if firstaddr==0:
                firstaddr=head
            pid=(head-firstaddr)>>20
            #print("%#x %#x %.6f %.6f"%(head,chunk.addr,(addr/1000000),(end/1000000)))
            inusestr="inuse"
            if inuse==0:
                inusestr="unuse"
            mapsize=head-chunk.mapendaddr
            fo.write("      %#x %.3fM-%d (1) [000] ...1 %.6f: tracing_mark_write: B|1|%d %s|chunk=%#x,pointer=%#x ,mchunk_size=%d\n"%(head,(mapsize/1024/1024),pid,(addr-head)/1000000,(size),inusestr,addr,(addr+0x10),chunk.mchunk_size))
            fo.write("      %#x %.3fM-%d (1) [000] ...1 %.6f: tracing_mark_write: E\n"%(head,(mapsize/1024/1024),pid,(end-head)/1000000))
        fo.close()


    def getAllbinchunk(self,arena,allchunklist):
        NBINS = 128
        i = 1
        while i< NBINS:
            self.getBinchunk(arena,i,allchunklist)
            i=i+1

    def getAddress(self,value):
        address="{}".format(value.address)
        if " " in address:
            address=address[:address.index(" ")]
        return address
        
    def getBinchunk(self,arena,i,allchunklist):
        #print("%s, %d"%(arena,i))
        #print(arena["bins"][(i - 1) * 2])
        arenaPtr=self.getAddress(arena.reference_value())
        #print("%s %s"%(arena.reference_value(),arenaPtr))
        mbinptrStr = "(mbinptr) (((char *) &(((struct malloc_state *) {})->bins[(({}) - 1) * 2])) - 16 )".format(arenaPtr,i)
        #print(mbinptrStr)
        bin = gdb.parse_and_eval(mbinptrStr)
        #print(bin)
        #print(bin["bk"])
        #print(bin["fd"])
        #print(bin["mchunk_size"])
        bk = bin["bk"]
        fd = bin["fd"]
        size = bin["mchunk_size"]
        if bin != bk:
            while bk != fd :
                #print("chunk={}\tsize={}".format(self.getAddress(fd.referenced_value()),fd["mchunk_size"]))
                allchunklist.append(self.getAddress(fd.referenced_value()))
                fd = fd["fd"]

        
    def getAllchunklist(self):
        allchunklist = []
        main_arena = gdb.parse_and_eval("main_arena")
        main_reference=main_arena.reference_value().address
        nextarena = main_arena
        nextarena_reference = None
        i=0
        while True:
            self.getAllbinchunk(nextarena,allchunklist)
            nextarena_reference=nextarena["next"]
            nextstr = "*(struct malloc_state *){}".format(nextarena_reference)
            #print("%s %s"%(main_reference,nextarena_reference))
            if main_reference == nextarena_reference:
                break
            i=i+1
            if i> 1000:
                print("data error, exit")
                break
            nextarena = gdb.parse_and_eval(nextstr)

        print("all free chunk size %d"%(len(allchunklist)))
        print("update maps done")
        allchunklist.sort()
        #for map in allchunklist:
        #    print(map)
        return allchunklist


    
    def invoke(self, arg, from_tty):
        self.dont_repeat()
        args = parseArg(arg)
        if len(args) < 1 :
            return self.__usage()
        self.update = False
        
        #update maps by free chunk
        if args[0] == "main_arena":
            self.update = True

        #self.update = True
        #maps[0]="00400000-00845000 r-xp 00000000 08:03 137651                             /usr/bin/node"
        #self.update = False
        #maps[0]="{00400000,00845000}"

        maps = self.getMaps()
        if self.update:
            allchunklist = self.getAllchunklist()
            maps=updatemapsbychunk.updatebychunk(maps,allchunklist,True)
            self.update = False
            maps=self.getMaps(os.path.abspath('.')+"/mapsnew")
        self.allChunmaps=self.getAllChunk(maps)
        self.createatrace()

    #
    def transition(self,maps):
        mapsnew = []
        if len(maps) == 0:
            print("transition maps is null")
        for map in maps:
            mapsnew.append("{}-{} rw-p 00000000 00:00 0 \n".format(str((hex((map[0])))),str((hex(map[1])))))
        for map in mapsnew:
            print(map)
        return mapsnew


def parseArg(strArg):
    seppattern = re.compile(r'''((?:[^ "']|"[^"]*"|'[^']*')+)''')
    return seppattern.split(strArg)[1::2]

Memoryinfo()

