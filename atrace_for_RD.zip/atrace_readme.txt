1. 连上adb，准备好问题复现现场；
2. 执行atrace_ex.bat或者atrace_ex.sh，可以传入抓取时间参数，默认为5秒；
3. 尽快操作复现问题，在trace总时间之内完成操作，等待trace结束；
4. trace完成后会pull文件出来并被解析为.atrace文件，会显示最终文件保存的路径。