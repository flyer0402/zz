# -*- coding: utf-8 -*-
import zlib
import sys
import os

def main(z_fp):
	atrace_fp = os.path.splitext(z_fp)[0] + '.atrace'
	with open(z_fp, 'rb') as f:
		trace_data = f.read()
	# Atrace content starts after "capturing trace..." marker
	try:
		trace_start = trace_data.index(b'capturing')
	except ValueError:
		raise RuntimeError('Systrace start marker not found')
	trace_data = trace_data[trace_start + 18:]
	# Do some cleanup for the newline
	if trace_data.startswith(b'\r\n'):
		trace_data = trace_data.replace(b'\r\n', b'\n')
	trace_data = trace_data[1:]
	
	# print '\nDecompress the atrace log'
	with open(atrace_fp, 'w') as f:
		f.write(zlib.decompressobj().decompress(trace_data).decode('gbk', 'ignore'))
	# print 'Atrace log is saved as ./atrace.log'

if __name__ == '__main__':
	if len(sys.argv) != 2:
		# print 'Usage: python extract_atrace.py input_name'
		exit(1)
	main(sys.argv[1])