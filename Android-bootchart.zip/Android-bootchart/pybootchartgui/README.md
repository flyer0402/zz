# pybootchartgui

## 介绍
Python3版本Android bootchart分析工具

fork：https://github.com/xrmx/bootchart，优化适配并简化使用方法



## 使用说明

1. 运行 `catch_bootchart.bat` ，抓取bootchart。
2. 运行 `pybootchartgui.exe`  解析 `bootchart.tgz` 。

注：catch_bootchart.bat、pybootchartgui.exe文件在dist目录下



## 安装依赖

```shell
pip install -r requirements.txt
```

