# Android-bootchart

## 介绍
Python3版本抓取Android bootchart

##更新日志
2023.12.01  初版


## 使用说明

1. 运行 `catch_bootchart.bat` 。
2. 云机输入ip:port，如：30.178.38.33:52085
   台架直接enter.
3. 运行结束，当前目录出现bootchart文件： bootchart_%日期%.png



## 安装依赖
1.安装pyhon3
2.cd pybootchartgui; 运行pip install -r requirements.txt 

