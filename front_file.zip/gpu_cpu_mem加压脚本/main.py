import subprocess
from time import sleep
import sys
import os
import math
import json
import threading
adb_shell = "adb -host shell "
adb_push = "adb -host push "

io_switch = False
mem_switch = False
cpu_switch = False
gpu_switch = False
io_nr = 0
mem_size = 0
cpu_idle = 0
gpu_percentage = 0

###########################################
#########         初始化          #########
###########################################


def init():
    init_coms = ["\"echo 'enable n' > /proc/alog\"", "\"mount -o remount,rw /\"",
                 "set_cpu_idle_8155 /usr/bin/", "stress /usr/bin/", "\"chmod 777 /usr/bin/stress\"", "\"chmod 777 /usr/bin/set_cpu_idle_8155\""]
    for com in init_coms:
        adb = adb_shell
        wait = 0
        if com == init_coms[2] or com == init_coms[3]:
            adb = adb_push
            wait = 2
        subprocess.Popen(adb + com, shell=True,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        sleep(wait)
    echo("初始化完成")

###########################################
#######   IO/CPU/MEM/GPU加压选项   ########
###########################################


def cpu(idle):
    cur = cpu_curr_idle()
    if (cur < idle):
        echo("CPU不需要加压")
        return
    nr = round((cur - idle) / 10)
    # subprocess.Popen(adb_shell + '\"' + "set_cpu_idle_8155 " + str(ret) + '\"',
    #                  shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8')
    echo("CPU加压开始:" + str(idle) + ",进程数：" + str(nr))
    subprocess.Popen(adb_shell + '\"' + "stress -c " + str(nr) + '\"',
                     shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8')
    echo_out(15)


def gpu(percentage):
    gpu_cur = gpu_curr_per()
    if(gpu_percentage < gpu_cur):
        echo("GPU不需要加压")
        return
    nr = math.ceil((gpu_percentage - gpu_cur) / 1)
    echo("GPU加压开始:" + str(percentage) + ",进程数：" + str(nr))
    for i in range(nr):
        subprocess.Popen(adb_shell + '\"' + "vts-simple-egl --id=0 --width=1920 --height=720" + '\"',
                         shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8')
        sleep(1)
    echo_gpu()

def mem(size):
    echo("MEM加压开始:" + str(size) + "M")
    subproc = subprocess.Popen(adb_shell + '\"' + "stress -m 1 --vm-bytes " + str(size) + 'M --vm-keep\"',
                               shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8')
    echo_out(4)


def io(nr):
    echo("IO加压开始:" + str(nr) + "进程")
    subprocess.Popen(adb_shell + '\"' + "stress -i " + str(nr) + '\"',
                     shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8')
    echo_io()

###########################################
#########         工具          ###########
###########################################


def echo(str):
    print("=========" + str + "=========")


def echo_out(index):
    out = subprocess.Popen(adb_shell + '\"' + "vmstat 2 |awk '{print $" + str(index) + "}'" + '\"',
                           shell=True, stdout=subprocess.PIPE)
    for next_line in out.stdout:
        return_line = next_line.decode("utf-8", "ignore")
        print(return_line)


def echo_io():
    out = subprocess.Popen(adb_shell + '\"' + "iostat 2|grep  -A 1 'iowait'" + '\"',
                           shell=True, stdout=subprocess.PIPE)
    for next_line in out.stdout:
        return_line = next_line.decode("utf-8", "ignore")
        print(return_line)


def echo_gpu():
    out = subprocess.Popen(adb_shell + '\"' + "while true; do cat /sys/devices/platform/soc/2c00000.qcom,kgsl-3d0/kgsl/kgsl-3d0/gpu_busy_percentage; sleep 2; done" + '\"',
                           shell=True, stdout=subprocess.PIPE)
    for next_line in out.stdout:
        return_line = next_line.decode("utf-8", "ignore")
        print(return_line)


def gpu_curr_per():
    out = subprocess.Popen(adb_shell + '\"' + "cat /sys/devices/platform/soc/2c00000.qcom,kgsl-3d0/kgsl/kgsl-3d0/gpu_busy_percentage" + '\"',
                           shell=True, stdout=subprocess.PIPE)
    cur = out.stdout.readline().decode("utf-8", "ignore")
    return int(cur.replace('%', ''))


def cpu_curr_idle():
    out = subprocess.Popen(adb_shell + '\"' + "iostat -c |tail -2|awk '{print $6}'" + '\"',
                           shell=True, stdout=subprocess.PIPE)
    cur = out.stdout.readline().decode("utf-8", "ignore")
    return float(cur.strip())


def parse_json():
    f = open("./config.json")
    items = json.load(f)
    global io_switch, mem_switch, cpu_switch, gpu_switch, io_nr, mem_size, cpu_idle, gpu_percentage

    io_switch = items['io']['switch_on']
    mem_switch = items['mem']['switch_on']
    cpu_switch = items['cpu']['switch_on']
    gpu_switch = items['gpu']['switch_on']
    cpu_idle = items['cpu']['idle']
    io_nr = items['io']['process']
    mem_size = items['mem']['size']
    gpu_percentage = items['gpu']['percentage']


###########################################
#########         main          ###########
###########################################

if __name__ == '__main__':
    init()
    parse_json()
    if(cpu_switch == "True"):
        cpu(cpu_idle)
    if(io_switch == "True"):
        io(io_nr)
    if(mem_switch == "True"):
        mem(mem_size)
    if(gpu_switch == "True"):
        gpu(gpu_percentage)
